#' filtnode
#' @description filtering methods for weighted graphs.
#' It offers to keep only the nodes with a weighted degree superior to a certain threshold.
#' The threshold can be chosen according to two methods.
#' - to keep a certain proportion of nodes only (quantile)
#' - retaining a certain number of nodes only (tops)
#' It enables to suppress isolates (keep_isolates)
#' and to remove a specific vertice from the network (rm_ego).
#' This last option is relevant for egonetwork analysis
#' i.e. removing ego from the network to analyse the relations between its alters.
#' @param g  an object of class \code{\link[igraph:igraph-package]{igraph}}
#' @param method  the method used to calculate which nodes to keep
#' quantile to select the share of nodes to keep
#' top to select the number of nodes to keep
#' @param param a proportion between 0 and 1 for the quantile method. All nodes with a weighted degree above this quantile will be kept.
#' a discrete number for the top method.
#' @param keep_isolates boolean; whether to keep the isolates (TRUE) or not (FALSE).
#' @param g_component  boolean; whether to keep the giant component only (TRUE) or all components (FALSE).
#' @param rm_ego a vertex name; removing ego from the graph for egonetwork analyses
#' @param narrative  a message summarising the method used - it can letter be used as a caption
#'
#' @return  an igraph object
#' @importFrom stats quantile
#' @export
#'
#' @examples
#' data(movies)
#' g <- netproj(movies, p = country, e = imdb_title_id)
#' g <- filtnode(g, method = "top", 100, keep_isolate = FALSE, g_component = TRUE, narrative = TRUE)
filtnode <- function (g, method = "quantile", param = 75, keep_isolates = TRUE, g_component = FALSE, rm_ego = NULL, narrative = TRUE)

{

  if (is.igraph(g) != "TRUE")
  {stop("incorrect class type, g must be of class igraph")}


  if (is.null(E(g)$weight))
  {stop("the weight attribute is null, the filtnode function only applies to weighted graphs")}

  # Compute the vertices strength
  V(g)$strength <- strength(g)

  if ( ! is.null(rm_ego)) {

    g <- delete_vertices(g, rm_ego)

  }

  o <- sum(E(g)$weight)

  if (method == "quantile") {

    #### Option 1: Select only nodes with a weighted degree superior to the chosen quantile

    cut <- quantile(x = V(g)$strength, probs = param/100)

    # Remove the links with a value inferior to the chosen quantile
    g <- delete_vertices(g, V(g)[strength <= cut])

  }

  if (method == "top") {

    #### Option 2: Select only the top nodes acording to the chosen threshold

    # Select the main relations
    toppart <- V(g)$strength[order(as.double(V(g)$strength), decreasing = TRUE)][1:param]

    cut <- toppart[[param]] # set the threshold

    # Remove the links with a value inferior to the threshold
    g <- delete_vertices(g, V(g)[strength < cut])

  }

  if (keep_isolates == F) {

    #### Keep only the connected nodes in the resulting subgraph 'gtop'

    # Measure the degree
    V(g)$degree <- degree(g)

    # Only keep the node with a degree different from zero
    g <- induced_subgraph(g, vids = V(g)$degree > 0)

  }

  if (g_component == T) {

    components <- components(g)

    #### Keep only the largest component

    vids <- V(g)[components$membership == which.max(components$csize)]

    g <- induced_subgraph(g, vids = vids)

  }

  ## Compute the share of relations that will be kept following the previous operations
  res <- sum(E(g)$weight)/o*100



  #### Display suggested manuscript text ####
  if (narrative == TRUE) {
    message("=== Suggested caption for the cartigraph layout - to insert in the source argument  ===")
    message(" ")

    text <- paste0(round(res, 2), "% of the relations weight were kept. Nodes were retained in the graph if their weighted degree was")
    if (method == "quantile") {text <- paste0(text, " in the top ", 100 - param, " %.")} # paste0(text, " above the quantile of probability ", param/100, ".")}
    if (method == "top") {text <- paste0(text, " among the top ", param, " by value.")}
    if (! is.null(rm_ego)) {text <- paste0(text, " The vertice ", rm_ego, " has been removed.")}
    if (g_component == T) {text <- paste0(text, " Only the giant component was kept.")}

    message(text)
  }

  return(g)
}
