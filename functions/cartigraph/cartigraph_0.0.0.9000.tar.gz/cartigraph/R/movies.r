#' 2017-2019 subset of the IMDb movies extensive dataset
#' contains international co-production only
#' original title, year and countries associated to each movie
#'
#' @format A data frame with 4664 rows and 4 variables:
#' \describe{
#'   \item{imdb_title_id}{Unique imdb identifier}
#'   \item{original_title}{Movie title}
#'   \item{year}{Production year}
#'   \item{country}{Production country}
#' }
#' @source \url{https://www.kaggle.com/stefanoleone992/imdb-extensive-dataset}
"movies"
