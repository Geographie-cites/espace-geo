#' Finch occurrence data from (Sanderson 2000) imported from package cooccur by Daniel M Griffith.
#' Occurrence data for 13 species from 17 sites. Columns are sites, rows are species. 1’s are presences
#' and 0’s are absences.
#'
#' @format A data frame with 13 observations and 17 variables.
#'
#' @source \url{https://cran.r-project.org/web/packages/cooccur/index.html}
"finches"
