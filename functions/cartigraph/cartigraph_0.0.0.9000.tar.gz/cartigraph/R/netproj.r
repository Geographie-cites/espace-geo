#' netproj
#' @description transforms two-mode data into a one-mode network.
#' From an edgelist stored in a daframe, it returns an igraph object.
#' Several projection methods are available. It draws on the implementation of the procedure outlined on
#' http://toreopsahl.com/2009/05/01/projecting-two-mode-networks-onto-weighted-one-mode-networks/
#' In addition to the 3 options provided by the projecting_tm function of the tnet package by Tore Opsahl,
#' it makes possible to apply a 4th option: the Netscity normalisation method.
#' The Netscity method also called "whole normalised counting" in bibliometrics
#' allows to divide the weight of each relation according to the number of actors connected to each artifacts.
#' In summing the edges' weights, you will get the total number of artifacts of the two-mode network.
#' More about this method and its application at \url{https://geoscimo.univ-tlse2.fr/general-methodology/methods/}
#' @param d an object of class dataframe with at least two columns containing
#' the two-mode edge list coding for the relations between entities of different types, or an igraph object.
#' Each line defines a relation.
#' @param p the name of the column containing the entities of type 1 ; p stands for person
#' @param e the name of the column containing the entities of type 1 ; e stands for event
#' @inheritParams tnetproj
#'
#' @return Returns an igraph object
#' @import igraph
#' @import tnet
#' @export
#'
#' @examples
#' library(igraph)
#' data("finches") #  contains the Galapagos dataset ("finches") from the `cooccur` package
#' g <- graph_from_incidence_matrix(as.matrix(finches), directed = FALSE, multiple = FALSE,
#' weighted = NULL, add.names = NULL)
#' d <- get.edgelist(g)
#' colnames(d) <- c("birds", "islands")
#' g <- netproj(d, birds, islands)
#'
netproj <- function (d, p, e, method = "Netscity")
{
  if (is.igraph(d) == "TRUE")
  {
    d <- get.edgelist(d)
  }


  p = substitute(p)
  e = substitute(e)

  d <- as.data.frame(d)
  net <- subset(d, select = c(eval(p), eval(e)))

  colnames(net) <- c("p","e")

  name <- data.frame(name = net$p, id = as.numeric(as.factor(net$p)))

  net <- cbind(p = as.numeric(as.factor(net$p)), e = as.numeric(as.factor(net$e)))

  net <- unique(net)

  onemode <- tnetproj(net, method = method)

  g <- graph_from_data_frame(cbind(onemode$i, onemode$j), directed = FALSE)

  E(g)$weight <- as.double(onemode$w)

  # Remove multiple lines

  g <- simplify(g, remove.multiple = TRUE, edge.attr.comb = c(weight = "first"))

  V(g)$name <- as.character(name$name[match(V(g)$name, name$id)])

  return(g)

}
