#' tnetproj
#' @description draws on the implementation of the procedure outlined on
#' http://toreopsahl.com/2009/05/01/projecting-two-mode-networks-onto-weighted-one-mode-networks/
#' It transforms a tnet object into a one-mode network according to different methods.
#' In addition to the 3 options provided by the projecting_tm function of the tnet package by Tore Opsahl,
#' it makes possible to apply a 4th option: the Netscity normalisation method.
#' The Netscity method also called "whole normalised counting" in bibliometrics
#' allows to divide the weight of each relation according to the number of actors connected to each artifacts.
#' In summing the edges' weights, you will get the total number of artifacts of the two-mode network.
#' More about this method and its application at \url{https://geoscimo.univ-tlse2.fr/general-methodology/methods/}
#' @param net tnet object
#' @param method The method-switch control the method used to calculate the weights.
#' binary sets all weights to 1
#' sum sets the weights to the number of cooccurences
#' Newman bases the weights on Newman’s (2001) method of discounting for the
#' size of collaborations.
#' Netscity bases the weights on Maisonobe et al.'s (2019) method of discounting for the
#' size of collaborations.
#'
#' @return  Returns a one-mode network
#' @import tnet
#' @export
#'
#' @examples
#'## define two-mode network
#'two.mode.net <- cbind(
#' i = c(1,1,2,2,2,2,2,3,4,5,5,5,6),
#' p = c(1,2,1,2,3,4,5,2,3,4,5,6,6))
#'## Run the function
#'tnetproj(two.mode.net, method = "Netscity")
#'
tnetproj <- function (net, method = "Netscity")
{
  if (is.null(attributes(net)$tnet)) {
    if (ncol(net) == 3) {
      net <- as.tnet(net, type = "weighted two-mode tnet")
    }
    else {
      net <- as.tnet(net, type = "binary two-mode tnet")
    }
  }
  if (attributes(net)$tnet != "binary two-mode tnet" & attributes(net)$tnet !=
      "weighted two-mode tnet")
    stop("Network not loaded properly")
  net2 <- net
  if (attributes(net)$tnet == "binary two-mode tnet")
    net2 <- cbind(net2, w = 1)
  net2 <- net2[order(net2[, "i"], net2[, "p"]), ]
  np <- table(net2[, "p"])
  net2 <- merge(net2, cbind(p = as.numeric(row.names(np)),
                            np = np))
  net1 <- merge(net2, cbind(j = net2[, "i"], p = net2[, "p"]))
  net1 <- net1[net1[, "i"] != net1[, "j"], c("i", "j", "w",
                                             "np")]
  net1 <- net1[order(net1[, "i"], net1[, "j"]), ]
  index <- !duplicated(net1[, c("i", "j")])
  w <- switch(method, binary = rep(1, sum(index)),
              sum = tapply(net1[,"w"], cumsum(index), sum),
              Netscity = tapply(1:nrow(net1),
                                cumsum(index), function(a) sum(net1[a, "w"]/((net1[a,"np"]*(net1[a,"np"]-1))/2))),
              Newman = tapply(1:nrow(net1),
                              cumsum(index), function(a) sum(net1[a, "w"]/(net1[a, "np"] - 1))))
  net1 <- cbind(net1[index, c("i", "j")], w = as.numeric(w))
  return(as.tnet(net1, type = "weighted one-mode tnet"))
}
