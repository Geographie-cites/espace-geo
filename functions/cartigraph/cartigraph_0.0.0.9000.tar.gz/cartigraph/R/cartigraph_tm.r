#' cartigraph_tm
#' @description plot a bipartite graph of class \code{\link[igraph:igraph-package]{igraph}}
#'  using the semiological features of the \code{\link[cartography]{cartography}} package.
#'  It enhances the graphical presentation of \code{\link[igraph:igraph-package]{igraph}}
#'   plots with layout elements, labels and legends.
#'   Vertices of different types have a different shape,
#'   and a legend is added to specify the type.
#' @param g  a bipartite graph of class \code{\link[igraph:igraph-package]{igraph}}
#' @param title  title of the plot
#' @param col.links  colour of edges
#' @param col.nodes  colours of the two types of nodes
#' @param layout layout function call to an
#'   \code{\link[igraph:igraph-package]{igraph}} layout function, such as
#'   \code{\link[igraph]{layout_nicely}} (the default), or a 2 column matrix
#'   giving the x and y coordinates for the vertices.
#'   See \code{\link[igraph]{layout_}} for details.
#' @param inches radius of the biggest circles in inches
#' @param legend.title.nodes title of the nodes' types legend
#' @param legend.title.links title of the proportional edges' legend
#' @param type name of the nodes' types
#' @param values.rnd.links  number of decimal places of the values displayed on the edges' legend values
#' @param sources  caption to be displayed below the graph
#' @param author  credit to be displayed below the graph
#' @param frame boolean; whether to add a frame to the plot (TRUE) or
#' not (FALSE).
#' @param col.frame  colour of the frame
#'
#' @return Returns a cartigraph plot
#' @import igraph
#' @import cartography
#' @importFrom graphics par
#' @importFrom graphics plot.new
#' @importFrom graphics legend
#' @importFrom grDevices adjustcolor
#' @export
#'
#' @examples
#' data(stations)
#' cartigraph_tm(stations,
#'               title = "Countries co-presence in Arctic according to scientific stations' locations",
#'               sources = "Sources: eu-interact. Data retrieved on Apr., 1 2021.",
#'               type = c("Country","Station's location"),
#'               legend.title.links = "Number of scientific stations")
cartigraph_tm <- function(g,
                          title = "My network",
                          col.links = adjustcolor("grey30", alpha.f = .6),
                          col.nodes = c("tomato", "lightblue"),
                          layout = igraph::layout_nicely(g, weight =  NULL),
                          inches = 0.03,
                          legend.title.nodes = "",
                          legend.title.links = "",
                          type = c("Type 1", "Type 2"),
                          values.rnd.links = 0,
                          sources = Sys.Date(),
                          author = "",
                          frame = TRUE,
                          col.frame = "#688994") {
  # specifying the shapes of the different types of nodes

  V(g)[V(g)$type == 1]$shape <- "square"
  V(g)[V(g)$type == 0]$shape <- "circle"

  ### mapping the bipartite network

  E(g)$weight <- 1

  g <- simplify(g, remove.multiple = TRUE, edge.attr.comb = c(weight = "sum", type = "ignore"))

  # choosing the colors of the two types of nodes

  col <- col.nodes

  # set the width of the larger link
  maxsize <- 10

  # set the width of all links according to the width of the larger link
  E(g)$width <-((E(g)$weight/max(E(g)$weight))*maxsize)

  # set the thresholds and width that will appear on the legend

  # 1. select 5 values between the min and the max value
  breaks.edge <- seq(max(E(g)$weight), min(E(g)$weight), length.out = 5)

  # 2. listing the corresponding links' width
  lwd.edge <- ((breaks.edge[1:4]/max(E(g)$weight))*maxsize)

  l2 <- layout

  plot.new()

  param <- par()
  oldparmar <- param$mar
  oldparusr <- param$usr

  # normalize the space where the nodes are plotted
  ln <- norm_coords(l2, ymin=-1, ymax=1, xmin=-1, xmax=1)

  # fix new graphical parameters
  par(mar = c(0,0,1.2,0), usr = c(-1.3,1.3,-1.3,1.3))
  # on.exit(par(param), add = TRUE)


  plot(g, rescale = F, layout = ln, add = T, edge.width = E(g)$width, # edge.curved=.1,
       vertex.size = 5,
       vertex.color = col[as.numeric(V(g)$type)+1],
       vertex.frame.color = "grey",
       vertex.label.family = "sans", # font
       vertex.label.color = "black", # text color,
       vertex.label.cex = 0.6
  )

  # add the legend of the links
  legendGradLines(pos = "topleft", # position of the legend
                  title.txt = legend.title.links, # title of the legend
                  title.cex = 0.6, values.cex = 0.6, # size of the text
                  breaks = breaks.edge, # values that are represented
                  lwd = lwd.edge, # edges width
                  col = "gray80", # color of the edges
                  values.rnd = values.rnd.links, # number of decimal digits
                  frame = F) # add a frame

  # legend of the nodes' types
  legend("topright", inset = .02, title = legend.title.nodes,
         type, col = col, pch = c(16, 15), horiz = F, cex = 0.8, box.col = "grey") # fill = col, border = "grey"

  # add the titles, authors and sources
  layoutLayer(title = title, coltitle = "white",
              sources = sources,
              # adding the north and scale of the graphic if relevant
              scale = NULL, north = F,
              author = author,  frame = frame, col = col.frame)

 on.exit(par(oldparmar))
 on.exit(par(oldparusr))
}
