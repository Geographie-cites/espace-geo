#' filtedge
#' @description filtering methods for weighted graphs.
#' It offers to keep only the links with a value superior to a certain threshold.
#' The threshold can be chosen according to two methods.
#' - to keep a certain proportion of links only (quantile)
#' - retaining a certain number of links only (tops)
#' It enables to suppress isolates (keep_isolates)
#' and to remove a specific vertice from the network (rm_ego).
#' This last option is relevant for egonetwork analysis
#' i.e. removing ego from the network to analyse the relations between its alters.
#' @param g an object of class \code{\link[igraph:igraph-package]{igraph}}
#' @param method the method used to calculate which edges to keep
#' quantile to select the share of links to keep
#' top to select the number of links to keep
#' @param param
#' a proportion between 0 and 1 for the quantile method. All links with a value above this quantile will be kept.
#' a discrete number for the top method.
#' @param keep_isolates boolean; whether to keep the isolates (TRUE) or not (FALSE).
#' @param g_component boolean; whether to keep the giant component only (TRUE) or all components (FALSE).
#' @param rm_ego a vertex name; removing ego from the graph for egonetwork analyses
#' @param narrative a message summarising the method used - it can letter be used as a caption
#'
#' @return an igraph object
#' @importFrom stats quantile
#' @export
#'
#' @examples
#' data(movies)
#' g <- netproj(movies, p = country, e = imdb_title_id)
#' g <- filtedge(g, method = "top", 100, narrative = TRUE)
#'
filtedge <- function (g, method = "quantile", param = 75, keep_isolates = F, g_component = F, rm_ego = NULL, narrative = T)

{

  if (is.igraph(g) != "TRUE")
  {stop("incorrect class type, g must be of class igraph")}


  if (is.null(E(g)$weight))
  {stop("the weight attribute is null, the filtedge function only applies to weighted graphs")}

  if ( ! is.null(rm_ego)) {

    g <- delete_vertices(g, rm_ego)

  }

  o <- sum(E(g)$weight)

  if (method == "quantile") {

    #### Option 1: Select only links with value superior to the chosen quantile

    cut <- quantile(x = E(g)$weight, probs = param/100)

    # Remove the links with a value inferior to the chosen quantile
    g <- delete_edges(g, E(g)[weight <= cut])

    }

  if (method == "top") {

    #### Option 2: Select only the top links acording to the chosen threshold

    # Select the main relations
    toplinks <- E(g)$weight[order(as.double(E(g)$weight), decreasing = TRUE)][1:param]

    cut <- toplinks[[param]] # set the threshold

    # Remove the links with a value inferior to the threshold
    g <- delete_edges(g, E(g)[weight < cut])

  }

  if (keep_isolates == F) {

    #### Keep only the connected nodes in the resulting subgraph 'gtop'

    # Measure the degree
    V(g)$degree <- degree(g)

    # Only keep the node with a degree different from zero
    g <- induced_subgraph(g, vids = V(g)$degree > 0)

  }

  if (g_component == T) {

    components <- components(g)

    #### Keep only the largest component

    vids <- V(g)[components$membership == which.max(components$csize)]

    g <- induced_subgraph(g, vids = vids)

  }

  ## Compute the share of relations that will be kept following the previous operations
  res <- sum(E(g)$weight)/o*100



  #### Display suggested manuscript text ####
  if (narrative == TRUE) {
    message("=== Suggested caption for the cartigraph layout - to insert in the source argument  ===")
    message(" ")

    text <- paste0(round(res, 2), "% of the relations weight were kept. Edges were retained in the graph if they were")
    if (method == "quantile") {text <- paste0(text, " in the top ", 100 - param, " % by value.")} # paste0(text, " above the quantile of probability ", param/100, ".")}
    if (method == "top") {text <- paste0(text, " among the top ", param, " by value.")}
    if (! is.null(rm_ego)) {text <- paste0(text, " The vertice ", rm_ego, " has been removed.")}
    if (g_component == T) {text <- paste0(text, " Only the giant component was kept.")}

    message(text)
  }

  return(g)
}
