#' Location of Arctic stations according to their affiliation countries.
#' A bipartite graph containing the list of arctic stations and their locations. Data retrieved by Mayline Strouk in April 2021.
#'
#' @format A bipartite graph of classe igraph with 94 edges and 2 types of vertices:
#' \describe{
#'   \item{Country}{country, the affiliation country of the station}
#'   \item{Station_place}{place, the location of the station}
#'   ...
#' }
#' @source \url{https://eu-interact.org/field-sites/}
"stations"
