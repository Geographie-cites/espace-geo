#' cartigraph
#' @description plot an object of class \code{\link[igraph:igraph-package]{igraph}}
#'  using the semiological features of the \code{\link[cartography]{cartography}} package.
#'  It enhances the graphical presentation of \code{\link[igraph:igraph-package]{igraph}}
#'   plots with layout elements, labels and legends.
#'   For weighted graphs, the radius of the nodes is proportional to their weighted degree,
#'   and the edges width is proportional to their weight.
#'   For bipartite graphs, vertices of different types have a different shape,
#'   and a legend is added to specifiy the type.
#' @param g an object of class \code{\link[igraph:igraph-package]{igraph}}
#' @param title title of the plot
#' @param col.links colour of edges
#' @param col.nodes colour of nodes
#' @param layout function call to an
#'   \code{\link[igraph:igraph-package]{igraph}} layout function, such as
#'   \code{\link[igraph]{layout_nicely}} (the default), or a 2 column matrix
#'   giving the x and y coordinates for the vertices.
#'   See \code{\link[igraph]{layout_}} for details.
#' @param inches radius of the biggest circles in inches
#' @param legend.title.nodes title of the proportional circles' legend
#' @param legend.title.links title of the proportional edges' legend
#' @param values.rnd.nodes number of decimal places of the values displayed on the nodes' legend
#' @param values.rnd.links number of decimal places of the values displayed on the edges' legend values
#' @param sources caption to be displayed below the graph
#' @param author credit to be displayed below the graph
#' @param frame boolean; whether to add a frame to the plot (TRUE) or
#' not (FALSE).
#' @param col.frame colour of the frame
#'
#' @return Returns a cartigraph plot
#' @import igraph
#' @import cartography
#' @importFrom graphics par
#' @importFrom graphics plot.new
#' @importFrom grDevices adjustcolor
#' @export
#'
#' @examples
#' library(igraph)
#' data("finches") #  contains the Galapagos dataset ("finches") from the `cooccur` package
#' g <- graph_from_incidence_matrix(as.matrix(finches), directed = FALSE, multiple = FALSE,
#'                                  weighted = NULL, add.names = NULL)
#' d <- get.edgelist(g)
#' colnames(d) <- c("birds", "islands")
#' g <- netproj(d, p = islands, e = birds)
#' cartigraph(g, title = "Galapagos finches", values.rnd.links = 2, values.rnd.nodes = 2)


cartigraph <- function(g,
                       title = "My network",
                       col.links = adjustcolor("grey30", alpha.f = .6),
                       col.nodes = "darkred",
                       layout = igraph::layout_nicely(g, weight =  NULL),
                       inches = 0.03,
                       legend.title.nodes = "",
                       legend.title.links = "",
                       values.rnd.nodes = 0,
                       values.rnd.links = 0,
                       sources = Sys.Date(),
                       author = "",
                       frame = TRUE,
                       col.frame = "#688994") {


  # Set the graphical parameters

  E(g)$color <- col.links
  V(g)$color <- col.nodes

  # Choose the variable to which the size of the circles should be proportional
  var <- igraph::strength(g)

  # Fix the surface of the largest circle
  smax <- inches * inches * pi

  # Fix the radius of the circles
  # we multiply by 200 because the igraph package divides, by default,
  # radius value per 200 (version 1.2.4.1)
  siz <- sqrt((var * smax/max(var))/pi)
  size <- siz*200

  # Set the size of the circles
  V(g)$size <- size

  # Select the values of the 4 sizes of circles that will be represented in the legend
  varvect <- seq(max(var), min(var), length.out = 4)

  # Set the width of the largest flow
  maxsize <- 10 # epaisseur du plus gros lien

  # Set the link thickness
  E(g)$width <-((E(g)$weight/max(E(g)$weight))*maxsize)

  # Set the thresholds and link thicknesses that will be represented in the legend

  # 1. Select 4 values between min. and max. val.
  breaks.edge <- seq(max(E(g)$weight), min(E(g)$weight), length.out = 4)

  # 2. list of thicknesses of the links appearing in the legend
  lwd.edge <- ((breaks.edge[1:3]/max(E(g)$weight))*maxsize)

  # Normalize the space in which the vertices are positioned
  ln <- igraph::norm_coords(layout, ymin = -1, ymax = 1, xmin = -1, xmax = 1)

  # Generate a new plot
  plot.new()

  param <- par()
  oldparmar <- param$mar
  oldparusr <- param$usr

  # Setting new graphic parameters
  par(mar = c(0, 0, 1.2, 0), usr = c(-1.3, 1.3, -1.3, 1.3)) ## xmin, xmax, ymin, et ymax

  # Adjust the size parameter of the legend circles (#cartography package)
  # taking into account the selected graphic parameters
  xinch <- diff(par("usr")[1L:2])/par("pin")[1L]
  sizevect <- inches/xinch

  # Plot the network and labels of the nodes
  igraph::plot.igraph(g, edge.curved = .1, rescale = F, layout = ln, add = T, main = "", edge.width = E(g)$width,
                      vertex.frame.color = "grey",
                      vertex.label.family = "sans", # labels' font
                      vertex.label.color = "black", # labels' color
                      vertex.label.degree = -pi/2, # label positioning angle
                      vertex.label.dist = sqrt(V(g)$size)/pi +0.2, # distance of labels
                      vertex.label.cex = 0.5) # labels' size

  # Add the legend indicating the size of the circles
  cartography::legendCirclesSymbols(pos = "topright", title.txt = legend.title.nodes,
                                    title.cex = 0.6, values.cex = 0.5,
                                    var = varvect, inches = sizevect, #circles' size
                                    col = "white", frame = F, values.rnd = values.rnd.nodes,
                                    style = "e") # choice of "extended" style for better readability

  # Add the legend indicating the thickness of the links
  cartography::legendGradLines(pos = "topleft", # legend position
                               title.txt = legend.title.links, # legend's title
                               title.cex = 0.6, values.cex = 0.6, # font size
                               breaks = breaks.edge, # intervals of the displayed values
                               lwd = lwd.edge, # link thickness
                               col = "gray80", # link color
                               values.rnd = values.rnd.links, # number of digits after the decimal point
                               frame = F) # legend's frame

  # Specify the title, source and author of the graphic
  cartography::layoutLayer(title = title, coltitle = "white",
                           sources = sources,
                           # possibility to add North and scale if necessary
                           scale = NULL, north = F,
                           author = author,  frame = frame, col = col.frame)

  on.exit(par(oldparmar))
  on.exit(par(oldparusr))

}
