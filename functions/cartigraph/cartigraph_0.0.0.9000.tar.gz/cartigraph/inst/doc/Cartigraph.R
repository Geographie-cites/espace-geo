## ----setup--------------------------------------------------------------------
library(cartigraph)

## ----weighted-----------------------------------------------------------------

library(cartigraph)
library(tnet)

# path to the geopackage file embedded in cartography
# path_to_data <- system.file("data", package = "cartigraph")
# movies <- load(file = "D:/Package/cartigraph/data/movies.rda")

data(movies)
head(movies)

g <- netproj(movies, p = country, e = imdb_title_id)

# sum(E(g)$weight) # It gives 1775, which is indeed the total number of international co-productions


## ----filtering----------------------------------------------------------------

library(cartigraph)

g <- filtedge(g, method = "quantile", 25, narrative = T)


## ----proplot, fig.width = 10--------------------------------------------------

library(cartigraph)

# cartigraph(g)

# Activate the following line if you want a pdf or svg output
# pdf(file="film-co-production.pdf", width = 8, height= 6)

cartigraph(g = g, 
           col.nodes = "red",
           col.links = adjustcolor("grey30", alpha=.6),
           inches = 0.03,
           title = "International film co-production from 2017 to 2019. The top 100 most frequent relations.", 
           legend.title.nodes = "Nb of co-produced films\nper country \n", 
           legend.title.links = "Normalised nb of\nco-produced films",
           values.rnd.nodes = 0,
           values.rnd.links = 1,
           sources = "IMDb movies extensive dataset (https://www.kaggle.com/stefanoleone992/imdb-extensive-dataset).\nOnly the movies having been rated at least 100 times on the imdb database are counted (data retrieved in Jan. 2020 by S. Leone).", 
           author = "M. Maisonobe, 2021", 
           frame = TRUE, 
           col.frame = "red")

# activate the following line if you want to clean up the graphics window
# dev.off()


## ----finches, fig.width = 10--------------------------------------------------

library(cartigraph)
library(tnet)

# head(finches)

g <- graph_from_incidence_matrix(as.matrix(finches), directed = FALSE, multiple = FALSE,
  weighted = NULL, add.names = NULL)
d <- get.edgelist(g)
colnames(d) <- c("birds", "islands")
g <- netproj(d, p = islands, e = birds)

# length(E(g))

g <- filtedge(g, "quantile", 25) # 101/136*100, 75 % of the links are kept

# quantile(x = E(g)$weight, probs = 0.25)

cartigraph(g, title = "Galapagos finches", col.nodes = "lightgreen", 
           values.rnd.links = 2, values.rnd.nodes = 2, col.frame = "lightgreen")


## ----stations, fig.width = 10-------------------------------------------------

library(cartigraph)

head(stations)

cartigraph_tm(stations,
              title = "Countries co-presence in Arctic according to scientific stations' locations",
              sources = "Sources: eu-interact; isaaffik; en.uit.no; forskningsradet.no; ipev; kopri; ncpor; nipr; cires1.colorado.edu. Data retrieved on Apr., 1 2021.",
              type = c("Country","Station's location"),
              legend.title.links = "Number of scientific stations")



